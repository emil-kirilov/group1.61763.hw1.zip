interface IFrontBookkeeper {
    String updateFront(String[] news);
}

public class FrontBookkeeper61763 implements IFrontBookkeeper {
	public FrontBookkeeper61763(){
	}
	
	public String updateFront(String[] news) {
	    NewsTransformer NS = new NewsTransformer(news); 
	    NS.sendCommands();
	    String toReturn = NS.getUpdateFront();
		return toReturn;
	}

}

